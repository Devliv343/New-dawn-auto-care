
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { MapPin, Phone, Mail } from "lucide-react";

export default function NewDawnAutoCare() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-gray-100 text-gray-800">
      <header className="flex items-center justify-between p-6 shadow-md bg-white">
        <h1 className="text-2xl font-bold">New Dawn Auto Care</h1>
        <nav className="space-x-6 text-lg">
          <a href="#services" className="hover:text-yellow-600">Services</a>
          <a href="#about" className="hover:text-yellow-600">About</a>
          <a href="#testimonials" className="hover:text-yellow-600">Testimonials</a>
          <a href="#contact" className="hover:text-yellow-600">Contact</a>
        </nav>
      </header>

      <section className="text-center py-20 bg-yellow-100">
        <h2 className="text-5xl font-extrabold mb-4">Rise and Shine</h2>
        <p className="text-xl mb-6">Your Car’s New Beginning Starts Here</p>
        <Button className="text-lg px-6 py-3">Book an Appointment</Button>
      </section>

      <section id="services" className="py-16 px-4 max-w-5xl mx-auto text-center">
        <h3 className="text-3xl font-bold mb-10">Our Services</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {['Oil Changes', 'Tire Services', 'Diagnostics', 'Detailing'].map(service => (
            <Card key={service} className="rounded-2xl shadow-md">
              <CardContent className="p-6">
                <h4 className="text-xl font-semibold mb-2">{service}</h4>
                <p>High-quality and reliable service tailored for your vehicle.</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section id="about" className="py-16 px-4 bg-gray-50 text-center">
        <h3 className="text-3xl font-bold mb-4">About Us</h3>
        <p className="max-w-2xl mx-auto text-lg">
          At New Dawn Auto Care, we believe in honest, friendly, and professional service. Our mission is to provide top-tier auto care that builds lasting trust with our customers.
        </p>
      </section>

      <section id="testimonials" className="py-16 px-4 max-w-4xl mx-auto text-center">
        <h3 className="text-3xl font-bold mb-10">What Our Customers Say</h3>
        <div className="space-y-6">
          <Card className="shadow-md">
            <CardContent className="p-6">
              <p className="text-lg italic">"Quick, honest, and great prices. Will definitely return!"</p>
              <p className="mt-2 font-semibold">- Jamie L.</p>
            </CardContent>
          </Card>
          <Card className="shadow-md">
            <CardContent className="p-6">
              <p className="text-lg italic">"They made my car look and feel brand new again."</p>
              <p className="mt-2 font-semibold">- Raj P.</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section id="contact" className="py-16 px-4 bg-gray-100">
        <h3 className="text-3xl font-bold text-center mb-8">Get in Touch</h3>
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <form className="space-y-4">
            <Input placeholder="Your Name" />
            <Input type="email" placeholder="Email Address" />
            <Textarea placeholder="Your Message" rows={4} />
            <Button type="submit">Send Message</Button>
          </form>
          <div className="space-y-4 text-lg">
            <p className="flex items-center"><MapPin className="mr-2" /> 123 Sunrise Blvd, Auto City</p>
            <p className="flex items-center"><Phone className="mr-2" /> (123) 456-7890</p>
            <p className="flex items-center"><Mail className="mr-2" /> info@newdawnauto.com</p>
            <p>Business Hours: Mon–Sat 8am–6pm</p>
          </div>
        </div>
      </section>

      <footer className="py-6 text-center text-sm bg-white border-t">
        &copy; {new Date().getFullYear()} New Dawn Auto Care. All rights reserved.
      </footer>
    </div>
  );
}
